package com.kita.first.mission;

public class Practice2 {
	public static void main(String[] args) {
		// 랜덤값 뽑기
		
	}
}
