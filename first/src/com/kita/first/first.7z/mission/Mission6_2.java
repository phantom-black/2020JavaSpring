package com.kita.first.mission;

public class Mission6_2 {
	public static void main(String[] args) {
		int star = 3;
		for ( int i=0; i < star; i++ ) {
			System.out.print("*");
		}
		System.out.println(); // for문 끝나고 개행
	}
}
