package com.kita.first.repeat;

public class While2 {
	public static void main(String[] args) {
		
		do {
			
		} while();
	
		
		while(true) {	// while문 최고의 형식
			
			if() {
				break;
			}
		}
	}
}
