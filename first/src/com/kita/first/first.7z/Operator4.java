package com.kita.first;

public class Operator4 {
	public static void main(String[] args) {
		int n1 = 10;
		int n2 = 3;
		
		System.out.println("몫 : " + n1 / n2);
		System.out.println("나머지 : " + n1 % n2); 	// % : 모드 -> 홀짝 구별에 이용
	}
}
