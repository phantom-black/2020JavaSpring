package com.kita.first;

public class Operator {
	public static void main(String[] args) {
		int n1 = 10;
		n1++;
		System.out.println(n1);	// n1=11
		
		++n1;
		System.out.println(n1);
		
		System.out.println("---------");
		
		int n2 = 10;
		System.out.println(n2 + 1);	// n2=10
		System.out.println(n2);
	}
}
