package com.kita.first.mission;

public class Mission3 {
	/*
	 성별을 입력해 주세요: (남/여)
	 키를 입력해 주세요:
	 
	 남자 기준 : 160
	 여자 기준 : 150
	 
	 "평균 미만입니다."
	 "평균입니다."
	 "평균 초과입니다."
	*/
	public static void main(String[] args) {
		
	}
}
