package com.kita.first;

public class HelloWorld2 {

	public static void main(String[] args) {
		System.out.print("제 이름은\n박연진입니다");
		
		// single line 주석
		/* 
		  multi line 주석
		  
		  
		  
		  
		  */

	}

}
