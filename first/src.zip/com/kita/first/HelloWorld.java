package com.kita.first;

public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("헬로우 월드!!");
		System.out.println("헬로우 월드!!");
		System.out.print("헬로우\n");
		System.out.print("월드!!");
	}
}
